from feature_engine.selection import DropFeatures
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier

from model.config.core import config
from model.processing import features as pp

steps = []

# Drop de features temporales (solo si existen)
if config.model_config.temp_features and len(config.model_config.temp_features) > 0:
    steps.append(
        (
            "drop_features",
            DropFeatures(features_to_drop=config.model_config.temp_features),
        )
    )

# Mapper de variables cualitativas
steps.append(
    (
        "mapper_qual",
        pp.Mapper(
            variables=config.model_config.qual_vars,
            mappings=config.model_config.qual_mappings,
        ),
    )
)

# Escalador
steps.append(
    (
        "scaler",
        MinMaxScaler(),
    )
)

# Modelo
steps.append(
    (
        "model",
        RandomForestClassifier(
            n_estimators=config.model_config.n_estimators,
            max_depth=config.model_config.max_depth,
            min_samples_split=config.model_config.min_samples_split,
            min_samples_leaf=config.model_config.min_samples_leaf,
            max_features=config.model_config.max_features,
            class_weight=config.model_config.class_weight,
            random_state=config.model_config.random_state,
        ),
    )
)

# Construir pipeline
obesity_pipe = Pipeline(steps)