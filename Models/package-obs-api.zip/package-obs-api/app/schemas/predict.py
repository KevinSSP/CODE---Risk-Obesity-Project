from typing import Any, List, Optional

from pydantic import BaseModel
from model.processing.validation import DataInputSchema

# Esquema de los resultados de predicción
class PredictionResults(BaseModel):
    errors: Optional[Any]
    version: str
    predictions: Optional[List[str]]

class DataInputSchema(BaseModel):
    Gender: str           # Male/Female
    Age: float
    Height: float
    Weight: float
    family_history_with_overweight: str  # yes/no
    FAVC: str           # yes/no
    FCVC: float
    NCP: float
    CAEC: str           # Sometimes/Frequently/Always/no
    SMOKE: str          # yes/no
    CH2O: float
    SCC: str            # yes/no
    FAF: float
    TUE: float
    CALC: str           # Sometimes/Frequently/Always/no
    MTRANS: str         # Walking/Public_Transportation/Motorbike/Car

# Esquema para inputs múltiples
class MultipleDataInputs(BaseModel):
    inputs: List[DataInputSchema]

    class Config:
        schema_extra = {
            "example": {
                "inputs": [
                    {
                        "Gender": "Male",
                        "Age": 23.0,
                        "Height": 1.68,
                        "Weight": 70.0,
                        "family_history_with_overweight": "no",
                        "FAVC": "yes",
                        "FCVC": 2.0,
                        "NCP": 3.0,
                        "CAEC": "Sometimes",
                        "SMOKE": "no",
                        "CH2O": 2.0,
                        "SCC": "no",
                        "FAF": 2.0,
                        "TUE": 2.0,
                        "CALC": "Frequently",
                        "MTRANS": "Walking"
                    }
                ]
            }
        }
