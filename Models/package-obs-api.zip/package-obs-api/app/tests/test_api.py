import math

import numpy as np
import pandas as pd
from fastapi.testclient import TestClient


def test_make_prediction(client: TestClient, test_data: pd.DataFrame) -> None:
    # Given

    possible_classes = [
        'Normal_Weight', 'Overweight_Level_I', 'Overweight_Level_II',
        'Obesity_Type_I', 'Insufficient_Weight', 'Obesity_Type_II', 'Obesity_Type_III'
    ]
    expected_no_predictions = len(test_data)

    payload = {
        # ensure pydantic plays well with np.nan
        "inputs": test_data.replace({np.nan: None}).to_dict(orient="records")
    }

    # When
    response = client.post(
        "http://localhost:8001/api/v1/predict",
        json=payload,
    )

    # Then
    assert response.status_code == 200
    result = response.json()
    
    predictions = result.get("predictions")
    assert isinstance(predictions, list)
    assert result.get("errors") is None
    assert len(predictions) == expected_no_predictions
    assert all(pred in possible_classes for pred in predictions)
